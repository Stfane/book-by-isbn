<?php

/**
 * Fired during plugin deactivation
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/includes
 */

/**
 * Fired during plugin deactivation.
 *
 * This class defines all code necessary to run during the plugin's deactivation.
 *
 * @since      1.0.0
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/includes
 * @author     Stéphane Irie <stfanesarl@gmail.com>
 */
class Book_By_Isbn_Deactivator {

	/**
	 * Short Description. (use period)
	 *
	 * Long Description.
	 *
	 * @since    1.0.0
	 */
	public static function deactivate() {

	}

}
