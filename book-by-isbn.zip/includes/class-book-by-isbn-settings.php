<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin
 * @author     Stéphane Irie <stfanesarl@gmail.com>
 */
class Book_By_Isbn_Settings {
	/**
	 * Initialize the class and set its properties.
     *
     * @since     2.3.0
     */
	public function __construct() {}

	/**
	 *
	 * @since   1.0.0
	 *
	 * @return  array    Array of google settings.
	 */
	public function get_book_by_isbn_googleapikey_option(){
		$defaults = array(
			'book_by_isbn_api_key' => ''
		);

		$settings = get_option( 'book_by_isbn_googleapikey' );
	    $settings = wp_parse_args( $settings, $defaults );

	    return apply_filters( 'book_by_isbn_googleapikey_option', $settings);
	}

	/**
	 *
	 * @since   1.0.0
	 *
	 * @return  array    Array of amazon settings.
	 */
	public function get_book_by_isbn_amazonapikey_option(){
		$defaults = array(
			'book_by_isbn_api_key' => ''
		);

		$settings = get_option( 'book_by_isbn_amazonapikey' );
	    $settings = wp_parse_args( $settings, $defaults );

	    return apply_filters( 'book_by_isbn_amazonapikey_option', $settings);
	}
}