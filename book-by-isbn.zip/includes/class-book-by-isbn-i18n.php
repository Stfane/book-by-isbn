<?php

/**
 * Define the internationalization functionality
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/includes
 */

/**
 * Define the internationalization functionality.
 *
 * Loads and defines the internationalization files for this plugin
 * so that it is ready for translation.
 *
 * @since      1.0.0
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/includes
 * @author     Stéphane Irie <stfanesarl@gmail.com>
 */
class Book_By_Isbn_i18n {


	/**
	 * Load the plugin text domain for translation.
	 *
	 * @since    1.0.0
	 */
	public function load_plugin_textdomain() {

		load_plugin_textdomain(
			'book-by-isbn',
			false,
			dirname( dirname( plugin_basename( __FILE__ ) ) ) . '/languages/'
		);

	}



}
