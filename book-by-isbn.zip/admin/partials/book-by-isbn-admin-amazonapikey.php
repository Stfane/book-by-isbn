<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin/partials
 */
?>