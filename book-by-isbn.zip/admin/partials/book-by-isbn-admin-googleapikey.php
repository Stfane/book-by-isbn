<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin/partials
 */
?>
<div id="container">
	<form action="options.php" method="post">
		<?php
			settings_fields( 'googleapikey_options' );
			do_settings_fields( 'googleapikey_options', '' );
		?>
		<div>
		    <h3><?php esc_html_e( 'Google API', $this->plugin_name ); ?></h3>
		    <p>
		      <?php printf( __( 'This plugin uses the Google Books API to automatically populate the details of a book. In order to take advantage of this feature, you must first sign up for and enter an API key as described <a href="%s" target="_blank">here</a>.', $this->plugin_name ), esc_url( 'https://github.com/Stfane/lfc-book' ) ); ?>
		    </p>
	  	</div>
	  	<div class="form-group">
		    <input type="text" class="form-control" id="book_by_isbn_api_key" placeholder="Google API Key" name="book_by_isbn_googleapikey[book_by_isbn_api_key]" value="<?php echo esc_attr( $googleapikey_options['book_by_isbn_api_key']); ?>">
		    <p>
		    	<?php
		    		printf( __( 'Your Google API key obtained from the <a href="%s" target="_blank">Google Developers Console</a>.', $this->plugin_name ), esc_url( 'https://console.developers.google.com/' ) );
		    	?>
		    	<?php esc_html_e( '', $this->plugin_name ); ?>
		    </p>
	  	</div>
	  	<?php submit_button(); ?>
	</form>
</div>