<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin/partials
 */
?>
<div class="container">
    <img class="center-block img img-responsive" src="<?php echo Woo_Lfc_Book_Loadfile::addFiles('assets/images', 'lafoirechretienne-logo', 'png', true); ?>" alt="Cover Image">
    <h1 class="text-center">Documentation</h1>

    <div class="col-md-9 col-md-offset-2 col-sm-12 col-xs-12">
        <h3>Google Book API key</h3>
        <p>First of all get your google book API key from this <a target="blank" href="https://developers.google.com/books/">link. </a> put it in the Google API key pages text box and save.</p>

        

        <h3>ISBN Single Product</h3>
        <p>This page is for quick importers who want a single book with price, quantity and other information set for the product. It will upload only a single book in the product section by its ISBN serial number.</p>

        <br>
        <br>
        <br>
        <p class="text-center">
            <a class="btn btn-info" target="blank" href="https://twitter.com/stfaneirie">Contact Me For More Information or Product Like This</a>
        </p>
    </div>
</div>