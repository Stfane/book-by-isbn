<?php

/**
 * The admin-specific functionality of the plugin.
 *
 * @link       twitter.com/stfaneirie
 * @since      1.0.0
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin
 */

/**
 * The admin-specific functionality of the plugin.
 *
 * Defines the plugin name, version, and two examples hooks for how to
 * enqueue the admin-specific stylesheet and JavaScript.
 *
 * @package    Book_By_Isbn
 * @subpackage Book_By_Isbn/admin
 * @author     Stéphane Irie <stfanesarl@gmail.com>
 */
class Book_By_Isbn_Admin {

	/**
	 * The ID of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $plugin_name    The ID of this plugin.
	 */
	private $plugin_name;

	/**
	 * The version of this plugin.
	 *
	 * @since    1.0.0
	 * @access   private
	 * @var      string    $version    The current version of this plugin.
	 */
	private $version;

	/**
	 * The settings of this plugin
	 * 
	 * @since    1.0.0
	 * @access   private
	 * @var      book_by_isbn_settings    $settings    Instance of Book_By_Isbn_Settings
	 */
	 private $settings;

	/**
	 * Initialize the class and set its properties.
	 *
	 * @since    1.0.0
	 * @param      string    $plugin_name       The name of this plugin.
	 * @param      string    $version    The version of this plugin.
	 */
	public function __construct( $plugin_name, $version, $settings ) {

		$this->plugin_name = $plugin_name;
		$this->version = $version;
		$this->settings = $settings;

	}

	/**
	 * Register the stylesheets for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_styles($hook_suffix) {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Book_By_Isbn_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Book_By_Isbn_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if ( !isset( $this->plugin_screen_hook_suffix ) ){
			return;
		}

		if ( $hook_suffix == 'edit.php' || 'options-general.php' ){
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/bootstrap.min.css', array(), $this->version, 'all' );
			wp_enqueue_style( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'css/book-by-isbn-admin.css', array(), $this->version, 'all' );
		}


	}

	/**
	 * Register the JavaScript for the admin area.
	 *
	 * @since    1.0.0
	 */
	public function enqueue_scripts($hook_suffix) {

		/**
		 * This function is provided for demonstration purposes only.
		 *
		 * An instance of this class should be passed to the run() function
		 * defined in Book_By_Isbn_Loader as all of the hooks are defined
		 * in that particular class.
		 *
		 * The Book_By_Isbn_Loader will then create the relationship
		 * between the defined hooks and the functions defined in this
		 * class.
		 */
		if (!isset( $this->plugin_screen_hook_suffix )){
			return;
		}
		if ( $hook_suffix == 'edit.php' || 'options-general.php' ){
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/book-by-isbn-admin.js', array( 'jquery' ), $this->version, false );
			wp_enqueue_script( $this->plugin_name, plugin_dir_url( __FILE__ ) . 'js/bootstrap.min.js', array( 'jquery' ), $this->version, false );

		}
		
	}

	/**
	 * Register the Admin menu for this plugin into the wordpress
	 * Dashboard menu.
	 * @since 1.0.0
	 */
	public function add_plugin_admin_menu(){
		$this->plugin_screen_hook_suffix = add_options_page(
			esc_html__( 'LFC Book Settings', $this->plugin_name ),
			esc_html__( 'LFC Book', $this->plugin_name),
			'manage_options',
			$this->plugin_name,
			array($this, 'display_plugin_admin_page')
		);
	}

	/**
	 * Render the settings page for this plugin.
	 * 
	 * @since 1.0.0
	 */
	public function display_plugin_admin_page(){
		include_once('partials/book-by-isbn-admin-display.php');
	}

	/**
	 * Add tabbed navigation
	 *
	 * @since 1.0.0
	 */
	public function render_tabs(){
		$tabs = apply_filters( 'lfc_book_tabs', array(
			'documentation' => __( 'Documentation', $this->plugin_name ),
			'googleapikey' => __( 'Google Api Key', $this->plugin_name ),
			'amazonapikey' => __( 'Amazon Api Key', $this->plugin_name)
		));

		if (isset( $_GET['tab'])){
			$active_tab = $_GET['tab'];
		}
		else {
			$active_tab = 'documentation';
		}

		foreach ($tabs as $tab => $name) {
			$class = ( $tab == $active_tab ) ? ' nav-tab-active' : '';

			echo '<a class="' . esc_attr( 'nav-tab' . $class ) . '" href="' . esc_url( '?page=book-by-isbn&tab=' . $tab ) . '">' . esc_html( $name ) . '</a>';
		}
	}

	/**
	 * Display the content for a particular tab.
	 *
	 * @since 1.0.0
	 */
	public function render_tabbed_content(){
		if ( isset($_GET['tab'])){
			$active_tab = $_GET['tab'];
		}
		else{
			$active_tab = 'documentation';
		}

		do_action('book_by_isbn_before_tabs');

		if ($active_tab == 'documentation'){
			include_once('partials/book-by-isbn-admin-documentation.php');
		}
		elseif ($active_tab == 'googleapikey') {
			$advanced_option = $this->settings->get_book_by_isbn_googleapikey_option();
			include_once('partials/book-by-isbn-admin-googleapikey.php');
		}
		elseif ($active_tab == 'amazonapikey') {
			$advanced_option = $this->settings->get_book_by_isbn_amazonapikey_option();
			include_once('partials/book-by-isbn-admin-amazonapikey.php');
		}

		do_action('book_by_isbn_after_tabs');
	}

	/**
	 * Add settings action link the plugins page.
	 *
	 * @since 1.0.0
	 */
	public function add_action_links($links){
		return array_merge(
			array(
				'settings' => '<a href="' . esc_url( admin_url( 'options-general.php?page=' .
        			$this->plugin_name ) ) . '">' . esc_html__( 'Settings', $this->plugin_name ) . '</a>'
			), $links);
	}

	/**
	 * Register settings so that they will be saved
	 *
	 * @since 1.0.0
	 */
	public function register_settings(){
		register_setting( 'googleapikey_options', 'book_by_isbn_googleapikey', array($this, 'save_googleapikey'));
		register_setting( 'amazonapikey_options', 'book_by_isbn_amazonapikey', array($this, 'save_amazonapikey'));
	}

	/**
     * Sanitize text.
     *
     * @since    1.0.0
     * @param    string       $text     Unsanitized text
     * @return   string                 Sanitized text
     */
	public function sanitize_text( $text ) {
    	return sanitize_text_field( $text );
	}

	/**
	 * Save Google api tab
	 *
	 * @since    1.0.0
	 */
	public function save_googleapikey(){
		$output = array();
		foreach ( $input as $key => $value ) {
    		$output[$key] = apply_filters( 'sanitize_' . $key, $value );
    	}

    	return $output;
	}

	/**
	 * Save Amazon api tab
	 *
	 * @since    1.0.0
	 */
	public function save_amazonapikey(){
		$output = array();
		foreach ( $input as $key => $value ) {
    		$output[$key] = apply_filters( 'sanitize_' . $key, $value );
    	}

    	return $output;
	}

}
